# File: pages/agent_chat.py
import streamlit as st
import sqlite3
from datetime import datetime, timedelta
from streamlit_autorefresh import st_autorefresh

# Optional: import chatbot if using Gemini or OpenAI
# from chatbot import get_bot_reply

def get_cutoff(minutes: int) -> datetime:
    return datetime.now() - timedelta(minutes=minutes)

def get_conn():
    return sqlite3.connect("app.db", check_same_thread=False)

def agent_chat_page():
    st_autorefresh(interval=15000, limit=None, key="chat_refresh")
    st.title(f"🛠️ Agent Chat – Ticket #{st.session_state.get('current_ticket_id')}")
    ticket_id = st.session_state.get("current_ticket_id")

    if not ticket_id:
        st.error("No ticket selected. Go back to the dashboard.")
        st.stop()

    conn = get_conn()
    c = conn.cursor()

    col1, col2 = st.columns(2)

    # ================================
    # 👤 Agent ↔ User Chat (Left Side)
    # ================================
    with col1:
        st.subheader("👤 Agent ↔ User Chat")

        # Load last 30 mins of chat
        cutoff = get_cutoff(30)
        c.execute(
            """
            SELECT sender, message, timestamp
              FROM chat_sessions
             WHERE ticket_id = ?
               AND timestamp >= ?
             ORDER BY timestamp
            """,
            (ticket_id, cutoff)
        )
        rows = c.fetchall()

        if not rows:
            st.warning("No chat history in the last 30 minutes.")
        else:
            for sender, message, _ in rows:
                role = "user" if sender == "user" else "assistant"
                with st.chat_message(role):
                    st.write(message)

        agent_input = st.chat_input("Your response to user…", key="user_chat_input")
        if agent_input:
            c.execute(
                """
                INSERT INTO chat_sessions 
                  (session_id, user_name, sender, message, timestamp, ticket_id)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    "agent-session",
                    st.session_state["user_name"],
                    "assistant",
                    agent_input,
                    datetime.now(),
                    ticket_id
                )
            )
            conn.commit()
            with st.chat_message("assistant"):
                st.write(agent_input)
            st.rerun()

        if st.button("✅ Mark Ticket Closed"):
            c.execute(
                """
                UPDATE Tickets
                   SET status = 'Closed', user_id = ?
                 WHERE id = ?
                """,
                (st.session_state["user_id"], ticket_id)
            )
            conn.commit()
            st.success("Ticket closed.")
            del st.session_state["current_ticket_id"]
            st.switch_page("pages/agent_dashboard.py")

    # ==================================
    # 🤖 Agent ↔ Bot Assistant (Right Side)
    # ==================================
    with col2:
        st.subheader("🤖 Agent Assistant (Chatbot)")

        if "bot_chat" not in st.session_state:
            st.session_state["bot_chat"] = []

        for role, msg in st.session_state["bot_chat"]:
            with st.chat_message(role):
                st.write(msg)

        agent_to_bot = st.chat_input("Ask assistant (e.g., summarize chat)…", key="bot_chat_input")
        if agent_to_bot:
            st.session_state["bot_chat"].append(("user", agent_to_bot))
            with st.chat_message("user"):
                st.write(agent_to_bot)

            # Simple placeholder logic — use actual bot in production
            # bot_reply = get_bot_reply(agent_to_bot)
            bot_reply = f"🤖 (Mock reply) You said: {agent_to_bot}"

            st.session_state["bot_chat"].append(("assistant", bot_reply))
            with st.chat_message("assistant"):
                st.write(bot_reply)

if __name__ == "__main__":
    agent_chat_page()