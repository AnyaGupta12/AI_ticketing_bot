import streamlit as st
import sqlite3
from datetime import datetime
from streamlit_autorefresh import st_autorefresh
from pages.chatbot import load_ticket_chat,load_kb_to_chroma, get_top_k_chunks, call_gemini_llm
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.utils import embedding_functions
# 🚨 ONLY CHANGED SECTIONS ARE MARKED WITH COMMENTS

def build_prompt(history, context, ticket, user_input):
    recent = history[-10:] if len(history) > 10 else history
    convo = "\n".join(f"{sender.capitalize()}: {msg}" for sender, msg in recent)

    prod, desc, prio, cid, contact_name = ticket
    ticket_info = (
        f"Ticket #{st.session_state.get('ticket_id')} info:\n"
        f"- Product: {prod}\n"
        f"- Priority: {prio}\n"
        f"- Description: {desc}\n"
        f"- Company ID: {cid}\n"
        f"- Contact Name: {contact_name}"
    )

    # 🚨 Include logic if no knowledge base context
    context_info = (
        "Knowledge Base Context:\n" + (context if context else "[NO_KB_MATCH]")
    )

    prompt = f"""
You are a helpful support assistant. Continue the conversation and assist the user based on the knowledge base and ticket context.

If the user's question:
- cannot be answered using the knowledge base,
- is unclear, illogical, or off-topic,
- or requires a human agent's help (e.g. refund requests, complaints, escalation, sensitive cases),

then **mark the response with**:

**[HANDOFF_REQUIRED]**

Do **NOT** trigger handoff for casual messages such as "hi", "hello", "how are you", "thank you", or other greetings or you feel it is normal human behavior.

{ticket_info}

Conversation so far:
{convo}

{context_info}

User: {user_input}

Assistant:"""
    return prompt.strip()

# ✅ Replace get_top_k_chunks with logic that returns both context and a boolean
def get_top_k_chunks(query, k=3):
    query_embedding = embedding_model.encode([query])[0].tolist()
    results = collection.query(query_embeddings=[query_embedding], n_results=k)
    docs = results['documents'][0] if results['documents'] else []
    return docs

def chatbot_page_agent()

    user_input = st.chat_input("Ask about your issue...")
    if user_input:

        if check_if_closing_message(user_input):
            c.execute("UPDATE Tickets SET status = 'closed' WHERE id = ?", (ticket_id,))
            conn.commit()
            st.success("✅ Ticket marked as closed. Thank you!")
            return

        # 🚨 1. Get KB chunks
        top_chunks = get_top_k_chunks(user_input, k=3)
        kb_context = "\n\n".join(top_chunks)
        has_kb_match = bool(top_chunks)

        # 🚨 2. If no chunks found, optionally inform LLM via context or handle separately
        if not has_kb_match:
            kb_context = ""  # Prompt will insert [NO_KB_MATCH]

        # 3. Call Gemini
        bot_reply = call_gemini_llm(
            history=history,
            context=kb_context,
            query=user_input,
            ticket=ticket
        )

        if "[HANDOFF_REQUIRED]" in bot_reply:
            c.execute("UPDATE Tickets SET status = 'Handoff' WHERE id = ?", (ticket_id,))
            conn.commit()
            st.warning("🔁 Your ticket has been marked for human assistance.")
            bot_reply = bot_reply.replace("[HANDOFF_REQUIRED]", "").strip()

        st.chat_message("user").write(user_input)
        st.chat_message("bot").write(bot_reply)

        save_chat_message(
            session_id=st.session_state["session_id"],
            sender="user",
            message=user_input,
            ticket_id=st.session_state["ticket_id"]
        )
        save_chat_message(
            session_id=st.session_state["session_id"],
            sender="assistant",
            message=bot_reply,
            ticket_id=st.session_state["ticket_id"]
        )